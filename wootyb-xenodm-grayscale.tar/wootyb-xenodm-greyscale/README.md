--- xenodm OpenBSD Grayscale Theme ---
author: wootyb
web: https://github.com/Wooty-B
email: wootyb@wootyb.com
special thanks: Roman Zolotarev, Zakaria and Vincent Delft


This theme is not only made to look good, but has comment's throughout
to help the average user modify it to their needs. This theme is meant
to be simple and straightforward and only uses two packages; the 'feh'
package is used to display a background image while the 'spleen'
package provides a nice font, however both are completely optional.

This theme was originally made on a 1024x768 display, so modifications
to the placement of the login box and power menu will more than likely
be necessary. The 'extras' folder contains a couple of variations of
the OpenBSD grayscale logo in case you need it, as well as a few
different background sizes for xenodm or the desktop wallpaper.

Over the course of a few hours figuring things out I learned a lot
about xenodm, the sed command, bash variables and the OpenBSD file
structrue. That being said, I highly recommend customizing your own
xenodm theme if you have the time as it is very rewarding!

Helpful tips:
- The Xresources file is primarily used for the login box elements
- The Xsetup_0 file is primarily used for the top bar (xclock), the
power menu (xmessage), and background elements and color.
- The GiveConsole file pretty much cleans things up once you log in.
If you run any additional programs remember to add a pkill line.
- Remember to chmod 755 if creating a new file under /etc/X11/xenodm!
